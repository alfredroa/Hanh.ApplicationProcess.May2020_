﻿
using Hahn.ApplicatonProcess.May2020.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System;

namespace Hahn.ApplicatonProcess.May2020.Data.DataContext
{
    public class DatabaseContext : DbContext
    {
        
        public class OptionsBuild
        {
            private ApplicationConfiguration appSettings { get; set; }
            public OptionsBuild()
            {
                appSettings = new ApplicationConfiguration();
                OpsBuilder = new DbContextOptionsBuilder<DatabaseContext>();
                OpsBuilder.UseInMemoryDatabase(databaseName: "Hanh_ApplicationProcess");
                //OpsBuilder.UseSqlServer(appSettings.SQLConnectionString);
                DbOptions = OpsBuilder.Options;
            }

            public DbContextOptionsBuilder<DatabaseContext> OpsBuilder { get; set; }
            public DbContextOptions<DatabaseContext> DbOptions { get; set; }
        }

        public static OptionsBuild Ops = new OptionsBuild();
        public DatabaseContext(DbContextOptions<DatabaseContext> options): base(options) { }

        //DBSets Go Here
        public DbSet<Applicant> Applicant { get; set; }
    }
}
