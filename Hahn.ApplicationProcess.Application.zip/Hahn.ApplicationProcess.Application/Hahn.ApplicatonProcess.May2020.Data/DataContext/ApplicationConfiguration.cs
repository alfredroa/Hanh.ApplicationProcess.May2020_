﻿using System.IO;
using Microsoft.Extensions.Configuration;

namespace Hahn.ApplicatonProcess.May2020.Data.DataContext
{
    public class ApplicationConfiguration
    {
        //Constructor
        public ApplicationConfiguration()
        {
            var configBuilder = new ConfigurationBuilder();
            var path = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");

            //configBuilder.AddInMemoryCollection (path, false);
            configBuilder.AddJsonFile(path, false);
            var root = configBuilder.Build();
            var appSetting = root.GetSection("ConnectionString:DefaultConnection");

            SQLConnectionString = appSetting.Value;
        }

        public string SQLConnectionString { get; set; }
    }
}
