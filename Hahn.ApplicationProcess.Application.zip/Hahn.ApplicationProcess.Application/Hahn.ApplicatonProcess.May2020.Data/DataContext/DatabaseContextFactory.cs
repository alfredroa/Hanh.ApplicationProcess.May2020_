﻿using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicatonProcess.May2020.Data.DataContext
{
    public class DatabaseContextFactory : IDesignTimeDbContextFactory<DatabaseContext>
    {
        public DatabaseContext CreateDbContext(string[] args)
        {
            ApplicationConfiguration appConfig = new ApplicationConfiguration();
            var opsBuilder = new DbContextOptionsBuilder<DatabaseContext>();
            
            return new DatabaseContext(opsBuilder.Options);
        }
    }
}
