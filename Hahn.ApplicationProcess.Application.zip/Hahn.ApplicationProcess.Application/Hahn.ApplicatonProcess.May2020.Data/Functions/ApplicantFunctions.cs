﻿using Hahn.ApplicatonProcess.May2020.Data.DataContext;
using Hahn.ApplicatonProcess.May2020.Data.Entities;
using Hahn.ApplicatonProcess.May2020.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.May2020.Data.Functions
{
    public class ApplicantFunctions : IApplicant
    {

        private readonly DatabaseContext _context;

        /// <summary>
        /// Add New Applicant
        /// </summary>
        /// <param name="applicant"></param>
        /// <returns></returns>
        public async Task<Applicant> Add(Applicant applicant)
        {
            using (var context = new DatabaseContext(DatabaseContext.Ops.DbOptions))
            {
                if (applicant.Hired)
                await context.Applicant.AddAsync(applicant);
                await context.SaveChangesAsync();
            }

            return applicant;
        }

        /// <summary>
        /// Get specific applicant 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Applicant>> Get()
        {
            IEnumerable<Applicant> _applicants;
            using (var context = new DatabaseContext(DatabaseContext.Ops.DbOptions))
            {
                _applicants = await context.Applicant
                   .Select(x => x).ToListAsync();

                if (_applicants.Count() <= 0)
                {
                    InitializeData();

                    _applicants = await context.Applicant
                        .Select(x => x).ToListAsync();
                }
            }

            return (IEnumerable<Applicant>)_applicants;
        }


        /// <summary>
        /// Get specific applicant by the ID
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<Applicant> Get(int id)
        {
            Applicant _applicant = new Applicant();
            using (var context = new DatabaseContext(DatabaseContext.Ops.DbOptions))
            {
                _applicant = await (from _a in context.Applicant.AsQueryable()
                                     where _a.Id == id
                                     select _a).FirstOrDefaultAsync();
            };

            return _applicant;
        }

        /// <summary>
        /// Update Applicant
        /// </summary>
        /// <param name="applicant"></param>
        /// <returns></returns>
        public async Task<Applicant> Update(Applicant applicant)
        {
            using (var context = new DatabaseContext(DatabaseContext.Ops.DbOptions))
            {
                context.Applicant.Update(applicant);
                context.SaveChanges();

                return applicant;
            }
        }

        /// <summary>
        /// Delete applicant
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Boolean> Delete(int id)
        {
            int isRemoved = 0;
            using (var context = new DatabaseContext(DatabaseContext.Ops.DbOptions))
            {
                var _applicant = await (from _a in context.Applicant.AsQueryable()
                                        where _a.Id == id
                                        select _a).FirstOrDefaultAsync();

                context.Applicant.Remove(_applicant);
                isRemoved = await context.SaveChangesAsync();
            }

            return isRemoved != 0 ? true : false;
        }

        #region DummyData
        private void InitializeData()
        {
            using (var context = new DatabaseContext(DatabaseContext.Ops.DbOptions))
            {
                // Return applicant list already in the database.
                if (context.Applicant.Any())
                {
                    return;
                }

                context.Applicant.AddRange(
                    new Applicant
                    {
                        Id = 1,
                        Name = "Bondat",
                        FamilyName = "Roa",
                        EmailAddress = "bondat@domain.com",
                        Age = 18,
                        Address = "4696  Davisson Street",
                        CountryOfOrigin = "USA"
                    },
                    new Applicant
                    {
                        Id = 2,
                        Name = "Borlalai",
                        FamilyName = "Roa",
                        EmailAddress = "borlali@domain.com",
                        Age = 19,
                        Address = "146  Sesame Street",
                        CountryOfOrigin = "Germany"
                    },
                    new Applicant
                    {
                        Id = 3,
                        Name = "Thomas L",
                        FamilyName = "Henderson",
                        EmailAddress = "6quopbpbtto@groupbuff.com",
                        Age = 53,
                        Address = "258  Woodland Avenue",
                        CountryOfOrigin = "USA"
                    },
                    new Applicant
                    {
                        Id = 4,
                        Name = "Joshua S",
                        FamilyName = "Cormier",
                        EmailAddress = "2yvsyvrj4wo@classesmail.com",
                        Age = 60,
                        Address = "978  Missouri Avenue",
                        CountryOfOrigin = "USA"
                    },
                    new Applicant
                    {
                        Id = 5,
                        Name = "Diane T",
                        FamilyName = "Samples",
                        EmailAddress = "6n7slmi761s@powerencry.com",
                        Age = 45,
                        Address = "1087  Leverton Cove Road",
                        CountryOfOrigin = "USA"
                    },
                    new Applicant
                    {
                        Id = 6,
                        Name = "Bobby W",
                        FamilyName = "Davis",
                        EmailAddress = "ntb453itwqk@meantinc.com",
                        Age = 38,
                        Address = "1906  Harter Street",
                        CountryOfOrigin = "Denmark"
                    });

                context.SaveChanges();
            }
        }
        #endregion
    }
}
