﻿using Hahn.ApplicatonProcess.May2020.Data.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.May2020.Data.Interfaces
{
    /// <summary>
    /// Expose required applicant functions
    /// </summary>
    public interface IApplicant
    {
        Task<Applicant> Add(Applicant applicant);
        Task<IEnumerable<Applicant>> Get();
        Task<Applicant> Get(int Id);
        Task<Applicant> Update(Applicant applicant);
        Task<Boolean> Delete(int id);

    }
}
