
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

using Hahn.ApplicatonProcess.May2020.Data.DataContext;
using System.IO;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using Serilog;
using Microsoft.Extensions.Logging.Configuration;

namespace Hahn.ApplicatonProcess.May2020.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //1. Get the IWebHost which will host this application.
            var host = CreateWebHostBuilder(args).Build();

            //2. Find the service layer within our scope.
            using (var scope = host.Services.CreateScope())
            {
                //3. Get the instance of DatabaseContext in Data Layer
                var services = scope.ServiceProvider;
                var context = services.GetRequiredService<DatabaseContext>();
            }
            
            Log.Logger.Information("Info log at " + DateTime.Now);

            host.Run();
        }

        //https://github.com/dotnet/aspnetcore/blob/9c017cd8054a55a2102369c3d526383d664c07ad/src/DefaultBuilder/src/WebHost.cs#L186
        //WebHost.cs should already be retreiving the Logging Section config by default at line 165
        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .ConfigureLogging((hostingContext, logging) =>
                {
                    logging.ClearProviders();
                    logging.AddDebug();
                    logging.AddSerilog();
                    logging.AddFilter("Microsoft", LogLevel.Information);
                    logging.AddFilter("System", LogLevel.Warning);
                })
                .UseKestrel()
                .UseStartup<Startup>();
    }
    }
