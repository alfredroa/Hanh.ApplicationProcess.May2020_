﻿using Hahn.ApplicatonProcess.May2020.Data.DataContext;
using Hahn.ApplicatonProcess.May2020.Data.Entities;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ILogger = Microsoft.Extensions.Logging.ILogger;

namespace Hahn.ApplicatonProcess.May2020.Web.Models
{
    public class ApplicantMemoryData
    {
        private static readonly ILogger _logger;
        public static async Task Initialize(IServiceProvider serviceProvider)
        {
            _logger.LogInformation("Adding Applicant List in Memory");

            using (var context = new DatabaseContext(DatabaseContext.Ops.DbOptions))
            {
                // Return applicant list already in the database.
                if (context.Applicant.Any())
                {
                    return;
                }

                context.Applicant.AddRange(
                    new Applicant
                    {
                        Id = 1,
                        Name = "Bondat",
                        FamilyName = "Roa",
                        EmailAddress = "bondat@domain.com",
                        Age = 18,
                        Address = "4696  Davisson Street",
                        CountryOfOrigin = "USA"
                    },
                    new Applicant
                    {
                        Id = 2,
                        Name = "Borlalai",
                        FamilyName = "Roa",
                        EmailAddress = "borlali@domain.com",
                        Age = 19,
                        Address = "146  Sesame Street",
                        CountryOfOrigin = "Germany"
                    },
                    new Applicant
                    {
                        Id = 3,
                        Name = "Thomas L",
                        FamilyName = "Henderson",
                        EmailAddress = "6quopbpbtto@groupbuff.com",
                        Age = 53,
                        Address = "258  Woodland Avenue",
                        CountryOfOrigin = "USA"
                    },
                    new Applicant
                    {
                        Id = 4,
                        Name = "Joshua S",
                        FamilyName = "Cormier",
                        EmailAddress = "2yvsyvrj4wo@classesmail.com",
                        Age = 60,
                        Address = "978  Missouri Avenue",
                        CountryOfOrigin = "USA"
                    },
                    new Applicant
                    {
                        Id = 5,
                        Name = "Diane T",
                        FamilyName = "Samples",
                        EmailAddress = "6n7slmi761s@powerencry.com",
                        Age = 45,
                        Address = "1087  Leverton Cove Road",
                        CountryOfOrigin = "USA"
                    },
                    new Applicant
                    {
                        Id = 6,
                        Name = "Bobby W",
                        FamilyName = "Davis",
                        EmailAddress = "ntb453itwqk@meantinc.com",
                        Age = 38,
                        Address = "1906  Harter Street",
                        CountryOfOrigin = "Denmark"
                    });

                context.SaveChanges();

                _logger.LogInformation(string.Format("{0} applicants added.", 6));
            }
        }
    }
}
