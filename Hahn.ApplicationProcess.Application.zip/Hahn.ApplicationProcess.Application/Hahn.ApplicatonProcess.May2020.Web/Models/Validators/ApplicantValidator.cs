﻿using FluentValidation;
using Microsoft.Extensions.Logging;
using System;
using ILogger = Microsoft.Extensions.Logging.ILogger;

namespace Hahn.ApplicatonProcess.May2020.Web.Models
{
    public class ApplicantValidator : AbstractValidator<Data.Entities.Applicant>
    {
        private readonly ILogger _logger;
        public ApplicantValidator()
        {
            try
            {
                // Name
                RuleFor(x => x.Name).NotEmpty().WithMessage("Name is empty.");
                RuleFor(x => x.Name).Length(5, 20).WithMessage("Name must be at least 5 characters long");

                //Family Name
                RuleFor(x => x.FamilyName).NotEmpty().WithMessage("Family Name is empty.");
                RuleFor(x => x.FamilyName).Length(5, 20).WithMessage("Family Name must be at least 5 characters long");

                //Address
                RuleFor(x => x.Address).NotEmpty().WithMessage("Address is empty.");
                RuleFor(x => x.Address).Length(10, 100).WithMessage("Address must be at least 10 characters long"); // a simply min/max validation

                RuleFor(x => x.Age).NotEmpty().WithMessage("Age is empty.");
                RuleFor(x => x.Age).Must(ValidateAge).WithMessage("Age must be between 20 - 60 only."); // can be done using InclusiveBetween(1,10) too
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.InnerException.Message);
                _logger.LogError(ex.StackTrace);

                throw ex;
            }
        }

        // Only allow within this range
        private bool ValidateAge(int age)
        {
            if (age >= 20 && age <= 60)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // String input at least 5 characters long
        // Can be expound further those complex ones
        private bool ValidateInputString(string stringValue)
        {
            if (stringValue.Length < 5)
                return false;

            return true;
        }

        // Integer input 
        //TODO: Add validation rules
        private bool ValidateInputLengthNumber(int intValue) 
        { 
            return true; 
        }
    }
}
