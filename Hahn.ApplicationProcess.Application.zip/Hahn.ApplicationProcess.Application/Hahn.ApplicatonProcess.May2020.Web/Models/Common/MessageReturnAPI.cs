﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.May2020.Web.Models.Common
{
    public class APIMessageResponse
    {
        private readonly ILogger _logger;
        public string Message { get; set; }
        public HttpStatusCode StatusCode { get; set; }
        public bool Success { get; set; }
        public object ReturnValue { get; set; }

        /// <summary>
        /// serializes the object into a json string via the JsonHelper class
        /// </summary>
        /// <param name="format"></param>
        /// <returns></returns>
        public string ToJson()
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(this);
        }

    }
}
