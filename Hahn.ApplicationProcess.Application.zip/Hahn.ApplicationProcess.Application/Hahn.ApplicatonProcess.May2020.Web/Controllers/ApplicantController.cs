﻿using System;
using System.Collections.Generic;
using System.Net;

using System.Net.Http.Headers;
using System.Threading.Tasks;
using FluentValidation.Results;
using Hahn.ApplicatonProcess.May2020.Data.DataContext;
using Hahn.ApplicatonProcess.May2020.Data.Entities;
using Hahn.ApplicatonProcess.May2020.Domain.ApplicantLogic;
using Hahn.ApplicatonProcess.May2020.Web.Models;
using Hahn.ApplicatonProcess.May2020.Web.Models.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ILogger = Microsoft.Extensions.Logging.ILogger;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hahn.ApplicatonProcess.May2020.Web.Controllers
{
    
    //[ApiController]
    public class ApplicantController : Controller
    {
        private readonly ILogger _logger;

        private readonly DatabaseContext _context;
        private ApplicantLogic applicantLogic = new ApplicantLogic();
        private ApplicantValidator _validate = new ApplicantValidator();

        
        // Constructor
        public ApplicantController(DatabaseContext context)
        {
            _context = context;
        }

        #region API Endpoints i.e. http://localhost/Applicant/Add/{id}

        // POST: Create Applicant 
        // Use for posting raw json data from request body
        [HttpPost("Application/AddApplication", Name = "Post json applicant via json as parameter. You can use API client UI to test; direct url operation is not allowed.")]
        public async Task<string> AddApplicant([FromBody] Applicant postData)
        {
            Applicant _newApplicant = new Applicant();
            //var data =JsonConvert.DeserializeObject(postData);
            ValidationResult _result = _validate.Validate(postData);
            // Validate input
            if (!_result.IsValid)
            {
                //add into the ModelErrors bucket for display in the View
                foreach (ValidationFailure failure in _result.Errors)
                {
                    ModelState.AddModelError(failure.PropertyName, failure.ErrorMessage);
                }
            }
            else
            {
                // Finally, no further validation errors
                _newApplicant = await applicantLogic.Add(postData);
            }

            APIMessageResponse retObject = new APIMessageResponse();
            // construct reponse message
            if (_result.IsValid)
            {
                retObject = new APIMessageResponse
                {
                    Message = "New applicant created.",
                    Success = true,
                    ReturnValue = "Applicant can be viewed via api/Applicant/Get/" + _newApplicant.Id.ToString(),
                    StatusCode = HttpStatusCode.Created //201
                };
            }
            else
            {
                retObject = new APIMessageResponse
                {
                    Success = false,
                    ReturnValue = _result.Errors,
                    StatusCode = HttpStatusCode.BadRequest //400
                };
            }

            return HandleResponse(retObject);
        }


        // PUT: Update Applicant api/Applicant/{id?}
        // Use for posting raw json data from request body
        [HttpPut(Name = "Update applicant via json as parameter. You can use API client UI to test; direct url operation is not allowed.")]
        public async Task<string> UpdateApplicant([FromBody] Applicant newData, int? id)
        {
            Applicant _newApplicant = new Applicant();
            //var data =JsonConvert.DeserializeObject(postData);
            ValidationResult _result = _validate.Validate(newData);
            // Validate input
            if (!_result.IsValid)
            {
                //add into the ModelErrors bucket for display in the View
                foreach (ValidationFailure failure in _result.Errors)
                {
                    ModelState.AddModelError(failure.PropertyName, failure.ErrorMessage);
                }
            }
            else
            {
                // Finally, no further validation errors
                _newApplicant = await applicantLogic.Add(newData);
            }

            APIMessageResponse retObject = new APIMessageResponse();
            // construct reponse message
            if (_result.IsValid)
            {
                retObject = new APIMessageResponse
                {
                    Message = "New applicant created.",
                    Success = true,
                    ReturnValue = "Applicant can be viewed via applicant/Get/" + _newApplicant.Id.ToString(),
                    StatusCode = HttpStatusCode.OK //201
                };
            }
            else
            {
                retObject = new APIMessageResponse
                {
                    Success = false,
                    ReturnValue = _result.Errors,
                    StatusCode = HttpStatusCode.BadRequest //400
                };
            }

            return HandleResponse(retObject);
        }


        // GET: api/Applicant/Get
        [HttpGet("Applicant/GetApplicants",Name = "Retrieve (ALL) existing applicants")]
        public async Task<string> GetApplicants()
        {
            try
            {   
               var _data = await applicantLogic.Get();

                return JsonConvert.SerializeObject(_data);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                _logger.LogError(ex.StackTrace);

                throw ex;
            }
        }

        //GET: api/Applicant/Get/{1}
        [HttpGet("Applicant/GetApplicant/{id}", Name = "Retrieve specific applicant based on Id")]
        public async Task<string> GetApplicant(int id)
        {
            try
            {
                var _data = await applicantLogic.Get(id);
                return JsonConvert.SerializeObject(_data);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                _logger.LogError(ex.StackTrace);

                throw ex;
            }
        }

        //DELETE : Delete applicant by id
        // api/Applicant/Delete/{id}
        [HttpGet("Applicant/Delete/{id}", Name ="Delete applicant by id")]
        public async Task<string> Delete(int id)
        {
            try
            {
                var _data = await applicantLogic.Get(id);

                APIMessageResponse retObject = new APIMessageResponse();
                if (_data != null)
                {
                    retObject = new APIMessageResponse
                    {
                        Message = "Applicant deleted successfully.",
                        Success = true,
                        ReturnValue = _data,
                        StatusCode = HttpStatusCode.OK //201
                    };
                }
                else
                {
                    retObject = new APIMessageResponse
                    {
                        Message = "Delete Error. Record not existing.",
                        Success = false,
                        ReturnValue = _data,
                        StatusCode = HttpStatusCode.BadRequest //201
                    };
                }

                return JsonConvert.SerializeObject(retObject);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                _logger.LogError(ex.StackTrace);

                throw ex;
            }
        }
        #endregion

        #region ActionResult methods

        // Index View
        public async Task<ActionResult<ApplicantViewModel>> Index()
        {
            try
            {
                var items = await applicantLogic.Get();

                List<ApplicantViewModel> applicantsForDiplay = new List<ApplicantViewModel>();
                foreach (Applicant item in items)
                {
                    ApplicantViewModel data = new ApplicantViewModel
                    {
                        Id = item.Id,
                        Name = item.Name,
                        FamilyName = item.FamilyName,
                        Address = item.Address,
                        CountryOfOrigin = item.CountryOfOrigin,
                        Age = item.Age,
                        Hired = item.Hired,
                        FullName = item.Name + " " + item.FamilyName,
                        EmailAddress = item.EmailAddress
                    };

                    applicantsForDiplay.Add(data);
                }

                return View(applicantsForDiplay);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                _logger.LogError(ex.StackTrace);

                throw ex;
            }
        }

        // Add page UI
        [HttpGet("Add")]
        public IActionResult Add()
        {
            return View();
        }

        // AddRawData UI

        public IActionResult AddRawData()
        {
            return View();
        }


        // Add applicant from UI
        public async Task<IActionResult> AddView(Data.Entities.Applicant applicant)
        {
            try
            {
                ValidationResult _result = _validate.Validate(applicant);

                // Validate inp
                if (!_result.IsValid)
                {
                    foreach (ValidationFailure failure in _result.Errors)
                    {
                        ModelState.AddModelError(failure.PropertyName, failure.ErrorMessage);
                    }

                    // Go back and display the errors
                    return View(applicant);
                }
                else
                {
                    await applicantLogic.Add(applicant);
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                _logger.LogError(ex.StackTrace);

                throw ex;
            }
        }

        // Edit page UI. Display applicant's existing details
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var _data = await applicantLogic.Get(id);

                return View(_data);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                _logger.LogError(ex.StackTrace);

                throw ex;
            }
        }

        // Edit view. Update applicant's edited details from the page
        public async Task<IActionResult> EditView(Data.Entities.Applicant applicant)
        {
            try
            {
                var _data = await applicantLogic.Update(applicant);

                return RedirectToAction("Index");
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                _logger.LogError(ex.StackTrace);

                throw ex;
            }
        }

        //Delete applicant's on the UI
        public async Task<IActionResult> DeleteView(int id)
        {
            try
            {
                var _data = await applicantLogic.Delete(id);

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                _logger.LogError(ex.StackTrace);

                throw ex;
            }
        }

        // Carve out the response into json
        private string HandleResponse(APIMessageResponse resp)
        {
            //writes the error message to the log if present
            _logger.LogInformation(resp.ToString());

            var err = new APIMessageResponse();
            err.Message = resp.Message;
            err.Success = resp.Success;
            err.StatusCode = resp.StatusCode;

            return JsonConvert.SerializeObject(err);
        }
        #endregion
    }
}
