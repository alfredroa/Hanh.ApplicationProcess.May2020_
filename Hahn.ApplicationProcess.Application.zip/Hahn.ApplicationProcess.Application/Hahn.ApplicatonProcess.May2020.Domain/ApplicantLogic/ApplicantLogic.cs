﻿using Hahn.ApplicatonProcess.May2020.Data.DataContext;
using Hahn.ApplicatonProcess.May2020.Data.Entities;
using Hahn.ApplicatonProcess.May2020.Data.Functions;
using Hahn.ApplicatonProcess.May2020.Data.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.May2020.Domain.ApplicantLogic
{
    public class ApplicantLogic
    {
        
        private IApplicant _applicantFunctions = new ApplicantFunctions();

        public async Task<Applicant> Add(Applicant newApplicant)
        {
            try
            {
                var result = await _applicantFunctions.Add(newApplicant);

                return result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all list
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<Applicant>> Get(bool? dataFormat=false)
        {
            try
            {  
                return await _applicantFunctions.Get();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get specific applicant by the id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Applicant> Get(int id)
        {
            try
            {
                var _item = await _applicantFunctions.Get(id);

                return _item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }


        public async Task<Applicant> Update(Applicant applicant)
        {
            try
            {
                await _applicantFunctions.Update(applicant);
                return applicant;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Boolean> Delete(int id)
        {
            try
            {
                return await _applicantFunctions.Delete(id);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

    }
}
